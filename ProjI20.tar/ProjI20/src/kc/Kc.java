package kc;

import java.util.ArrayList;

/**
 * 注意: ここにある注意事項は全て削除して、自分で考えたコメントに書き換えて提出す
 * ること。ここの文言がそのまま残っている場合は、プログラムの内容を見ずに0点とする。
 * 
 * このクラス宣言や、各メソッド宣言部に、必ずドキュメンテーションコメントを記入すること。
 * また、フィールドや重要なローカル変数にもその役割がわかるようなコメントをつけること。
 * メソッド内で工夫した点や分かりにくい処理など、極力コメントをつけ、後で見て内容がすぐ
 * に把握できるようにしておくこと。
 *
 * これらのコメントがいい加減に記述されている場合、プログラムの内容を見ずに0点とする。
 */
public class Kc {
    
    /**
     * 
     */
    Kc(String sourceFileName) {
       
    }

    /**
     * 
     */
    parseProgram() {
       
    }

	
	
	
	  //以降、必要なparse...メソッドを追記する。
	
	
	

	/**
	 * 現在読んでいるファイルを閉じる (lexerのcloseFile()に委譲)
	 */
	void closeFile() {
		lexer.closeFile();
	}

	/**
	 * アセンブラコードをファイルに出力する (isegのdump2file()に委譲)
	 */
	void dump2file() {
		iseg.dump2file();
	}

	/**
	 * アセンブラコードをファイルに出力する (isegのdump2file()に委譲)
	 * 
	 * @param fileName 出力ファイル名
	 */
	void dump2file(String fileName) {
		iseg.dump2file(fileName);
	}

	/**
	 * エラーメッセージを出力しプログラムを終了する
	 * 
	 * @param message 出力エラーメッセージ
	 */
	private void syntaxError(String message) {
		System.out.print(lexer.analyzeAt());
		//下記の文言は自動採点で使用するので変更しないでください。
		System.out.println("で構文解析プログラムが構文エラーを検出");
		System.out.println(message);
		closeFile();
		System.exit(1);
	}

	/**
	 * 引数で指定したK20言語ファイルを解析する 読み込んだファイルが文法上正しければアセンブラコードを出力する
	 */
	public static void main(String[] args) {
		Kc parser;

		if (args.length == 0) {
			System.out.println("Usage: java kc.Kc20 file [objectfile]");
			System.exit(0);
		}

		parser = new Kc(args[0]);

		parser.parseProgram();
		parser.closeFile();

		if (args.length == 1)
			parser.dump2file();
		else
			parser.dump2file(args[1]);
	}
}