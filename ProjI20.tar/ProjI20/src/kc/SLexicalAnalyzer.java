package kc;

/**
 * 注意: ここにある注意事項は全て削除して、自分で考えたコメントに書き換えて提出す
 * ること。ここの文言がそのまま残っている場合は、プログラムの内容を見ずに0点とする。
 * 
 * このクラス宣言や、各メソッド宣言部に、必ずドキュメンテーションコメントを記入すること。
 * また、フィールドや重要なローカル変数にもその役割がわかるようなコメントをつけること。
 * メソッド内で工夫した点や分かりにくい処理など、極力コメントをつけ、後で見て内容がすぐ
 * に把握できるようにしておくこと。
 *
 * これらのコメントがいい加減に記述されている場合、プログラムの内容を見ずに0点とする。
 */
class SLexicalAnalyzer {
    private FileScanner sourceFileScanner; // 入力ファイルのFileScannerへの参照

    /**
     * 
     */
    SLexicalAnalyzer(String sourceFileName) {
        
    }

    /**
     * 
     */
    nextToken() {
        
    }

    /**
     * 
     */
    closeFile() {

    }

    /** 
     * 
     */
    void syntaxError() {
        System.out.print (sourceFileScanner.scanAt());
        //下記の文言は自動採点で使用するので変更しないでください。
        System.out.println ("で字句解析プログラムが構文エラーを検出");
        closeFile();
        System.exit(1);
    }
}