package kc;

import java.nio.file.*;
import java.io.*;

/**
 * 注意: ここにある注意事項は全て削除して、自分で考えたコメントに書き換えて提出す
 * ること。ここの文言がそのまま残っている場合は、プログラムの内容を見ずに0点とする。
 * 
 * このクラス宣言や、各メソッド宣言部に、必ずドキュメンテーションコメントを記入すること。
 * また、フィールドや重要なローカル変数にもその役割がわかるようなコメントをつけること。
 * メソッド内で工夫した点や分かりにくい処理など、極力コメントをつけ、後で見て内容がすぐ 
 * に把握できるようにしておくこと。
 *
 * これらのコメントがいい加減に記述されている場合、プログラムの内容を見ずに0点とする。
 */
class FileScanner {

	/**
	 * 引数 sourceFileName で指定されたファイルを開き, sourceFile で参照する．
	 * 教科書 p. 210 ソースコード 10.1 ではtry-with-resources 文を用いて
	 * ファイルの 参照と読み取りを一度に行っているが，このコンストラクタでは
	 * ファイルの参照 だけを行う．
	 * また lineNumber, columnNumber, currentCharacter, nextCharacter を初期化する
	 * 
	 * @param sourceFileName ソースプログラムのファイル名
	 */
	FileScanner(String sourceFileName) {
		Path path = Paths.get(sourceFileName);
		// ファイルのオープン
		try {
			sourceFile = Files.newBufferedReader(path);
		} catch (IOException err_mes) {
			System.out.println(err_mes);
			System.exit(1);
		}

		// 各フィールドの初期化

	}

	/**
	 * sourceFileで参照しているファイルを閉じる
	 */
	void closeFile() {
		try {
			sourceFile.close();
		} catch (IOException err_mes) {
			System.out.println(err_mes);
			System.exit(1);
		}
	}

	/**
	 * sourceFile で参照しているファイルから一行読み, フィールド line(文字列変数) に
	 * その行を格納する 教科書 p. 210 ソースコード10.1 では while文で全行を読み取って
	 * いるが，このメソッド内では while文は使わず1行だけ読み取りフィールドline に格納する．
	 */
	void readNextLine() {
		try {
			if (sourceFile.ready()) { // sourceFile中に未読の行があるかを確認 (例外:IllegalStateException)
				/*
				 * nextLineメソッドでsourceFileから1行読み出し 
				 * 読み出された文字列は改行コードを含まないので 
				 * 改めて改行コードをつけ直す
				 */

			} else {

			}
		} catch (IOException err_mes) { // 例外は Exception でキャッチしてもいい
			// ファイルの読み出しエラーが発生したときの処理
			System.out.println(err_mes);
			closeFile();
			System.exit(1);
		}
	}

	/**
	 *
	 */
	lookAhead() {

	}

	/**
	 *
	 */
	getLine() {

	}

	/**
	 * 
	 */
	// 問題 2.6 に取り掛かる段階でここのコメントアウトを外す
	// nextChar() {
	//
	// }

	/**
	 * 
	 */
	// 問題 2.7 に取り掛かる段階でここのコメントアウトを外す
	// scanAt() {
	//
	// }

	public static void main(String args[]) {

	}
}