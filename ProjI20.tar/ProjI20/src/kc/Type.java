package kc;

enum Type {
    INT,            /* int型 */
    ARRAYOFINT,     /* int型配列 */
    NULL            /* null */
}
